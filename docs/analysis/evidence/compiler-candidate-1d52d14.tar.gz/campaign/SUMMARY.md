# COMPILER-CANDIDATE execution evidence

Scope: unqualified protocol execution. Publication eligible: false.

No ranking is inferred. A qualification pass is one process block, not complete-case acceptance.

| SDK | Instance | Qualification outcome | Full-case outcome | Records |
| --- | --- | --- | --- | --- |
| fq-source-ordinary | ROUTE-LINE-06 | accepted | accepted | 30 |
| fq-source-ordinary | ROUTE-GRID-08 | accepted | accepted | 30 |
| fq-source-ordinary | ROUTE-LINE-12 | accepted | accepted | 30 |
| fq-source-target | ROUTE-LINE-06 | accepted | accepted | 30 |
| fq-source-target | ROUTE-GRID-08 | accepted | accepted | 30 |
| fq-source-target | ROUTE-LINE-12 | accepted | accepted | 30 |
| qiskit-release-transpile | ROUTE-LINE-06 | accepted | accepted | 30 |
| qiskit-release-transpile | ROUTE-GRID-08 | accepted | accepted | 30 |
| qiskit-release-transpile | ROUTE-LINE-12 | accepted | accepted | 30 |
| cirq-release-route | ROUTE-LINE-06 | accepted | accepted | 30 |
| cirq-release-route | ROUTE-GRID-08 | accepted | accepted | 30 |
| cirq-release-route | ROUTE-LINE-12 | accepted | accepted | 30 |
